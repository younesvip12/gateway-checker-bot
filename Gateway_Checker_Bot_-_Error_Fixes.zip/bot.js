import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import { handleStart, handleHelp, handleStop } from './handlers/commands.js';
import { handleCallbackQuery } from './handlers/callbacks.js';
import { handleDocument } from './handlers/document.js';
import { config } from './config/config.js';

dotenv.config();

if (!config.botToken) {
  console.error('❌ Error: BOT_TOKEN not found in .env file!');
  console.error('Please create a .env file with: BOT_TOKEN=your_token_here');
  process.exit(1);
}

const bot = new TelegramBot(config.botToken, { 
  polling: {
    interval: 2000,
    autoStart: true,
    params: {
      timeout: 10
    }
  }
});

console.log('✅ Gateway Checker Bot is running...');
console.log('📱 Waiting for messages...');

bot.onText(/\/start/, (msg) => handleStart(bot, msg));
bot.onText(/\/help/, (msg) => handleHelp(bot, msg));
bot.onText(/\/stop/, (msg) => handleStop(bot, msg));

bot.on('callback_query', (query) => handleCallbackQuery(bot, query));
bot.on('document', (msg) => handleDocument(bot, msg));

bot.on('polling_error', (error) => {
  if (error.code === 'EFATAL' || error.code === 'ECONNABORTED') {
    console.log('⚠️ Connection issue, retrying...');
    setTimeout(() => {
      console.log('🔄 Reconnecting...');
    }, 3000);
  } else {
    console.error('❌ Polling error:', error.message);
  }
});

process.on('unhandledRejection', (error) => {
  console.error('⚠️ Unhandled error:', error.message);
});

bot.on('message', (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  
  if (!msg.document) {
    bot.sendMessage(msg.chat.id, 'Please send a text file with cards or use /start to begin.', {
      parse_mode: 'HTML'
    }).catch(err => console.error('Error sending message:', err.message));
  }
});
  