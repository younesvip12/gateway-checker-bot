# 🚀 QUICKEST WAY - Railway Deployment (5 Minutes!)

## You Need:
1. ✅ Bot token from @BotFather
2. ✅ Email address
3. ✅ That's it!

## Steps:

### 1️⃣ Get Bot Token (2 minutes)
- Open Telegram
- Search: `@BotFather`
- Send: `/newbot`
- Follow instructions
- **Copy the token** (looks like: `123456:ABCdef...`)

### 2️⃣ Deploy on Railway (3 minutes)

**Option A - Without GitHub (Simplest):**

1. Go to: `railway.app`
2. Click "Start a New Project"
3. Click "Empty Project"
4. In your project, click "New" → "GitHub Repo"
5. Connect this project's GitHub URL
6. Click "Variables" tab
7. Click "New Variable"
   - Name: `BOT_TOKEN`
   - Value: Paste your bot token
8. Click "Add"
9. Wait 2-3 minutes for deployment

**Option B - With GitHub (Recommended):**

1. Create account on github.com
2. Create new repository (make it public)
3. Upload all bot files to that repository
4. Go to railway.app
5. Login with GitHub
6. Click "New Project" → "Deploy from GitHub repo"
7. Select your repository
8. Add environment variable:
   - `BOT_TOKEN` = your token
9. Deploy!

### 3️⃣ Test Your Bot
- Open Telegram
- Search for your bot
- Send `/start`
- It works! 🎉

---

## Check if Bot is Running:

1. Go to railway.app
2. Open your project
3. Look for "Active" status with green dot
4. Check logs to see activity

---

## That's It!

Your bot is now:
- ✅ Running 24/7
- ✅ No phone needed to keep it on
- ✅ Accessible from anywhere
- ✅ Free for 500 hours/month

## Update Your Bot Later:

1. Change files on GitHub
2. Railway auto-deploys
3. Done!

---

**Still confused? Tell me where you're stuck!**