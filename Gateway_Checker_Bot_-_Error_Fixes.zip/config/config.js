import dotenv from 'dotenv';

dotenv.config();

export const config = {
  botToken: process.env.BOT_TOKEN,
  adminIds: process.env.ADMIN_IDS ? process.env.ADMIN_IDS.split(',').map(id => parseInt(id)) : [],
  gateways: [
    { name: 'PayPal_Custom_Cvv_Refund', id: 'paypal_cvv', price: 1 },
    { name: 'Stripe_Basic', id: 'stripe_basic', price: 2 },
    { name: 'Braintree_Auth', id: 'braintree_auth', price: 3 }
  ]
};