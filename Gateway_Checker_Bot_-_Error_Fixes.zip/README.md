# Telegram Gateway Checker Bot

A Telegram bot for checking payment card validity across multiple gateways.

## Features

- Multiple gateway support
- Real-time checking status
- Card validation tracking
- Approved/Declined/Charged statistics
- Easy-to-use interface
- Better error handling and retry logic

## Quick Setup

### 1. Get Bot Token
1. Open Telegram → Search `@BotFather`
2. Send `/newbot` and follow instructions
3. Copy your bot token

### 2. Install Dependencies
```bash
npm install
```

### 3. Create .env File
```bash
BOT_TOKEN=your_bot_token_here
```

### 4. Start Bot
```bash
npm start
```

## Troubleshooting

### Connection Errors (ECONNABORTED)

If you see connection errors:

**Fix 1: Check Internet**
- Make sure your device has stable internet
- Try switching between WiFi and mobile data

**Fix 2: Restart Bot**
```bash
# Stop the bot (Ctrl+C)
# Wait 5 seconds
npm start
```

**Fix 3: Use Better Connection**
- Connection issues happen on slow/unstable internet
- Try running on WiFi instead of mobile data
- Or use Railway/Render for 24/7 hosting (no connection issues)

### Bot Not Responding

1. Check if bot token is correct in .env file
2. Make sure you started the bot with `/start` command
3. Check console for error messages

## Deploy Online (24/7)

### Railway (Recommended)
1. Push code to GitHub
2. Connect GitHub to Railway.app
3. Add BOT_TOKEN environment variable
4. Deploy - runs automatically!

### Render
1. Push code to GitHub
2. Create new Web Service on Render.com
3. Connect your repository
4. Add BOT_TOKEN environment variable
5. Deploy

## Running on Mobile

### Termux (Android)
```bash
pkg update && pkg upgrade
pkg install nodejs-lts
cd gateway-bot
npm install
npm start
```

**Note:** Keep Termux running in background for bot to work.

## Commands

- `/start` - Show gateway options and start bot
- `/stop` - Stop current checking process
- `/help` - Show help message

## Card Format

Send a text file with cards in this format (one per line):
```
4107486757451294|06|2026|237
5358251949963942|08|2025|636
```

Format: `cardnumber|month|year|cvv`

## Support

If you encounter issues:
1. Check the Troubleshooting section above
2. Make sure your .env file has valid BOT_TOKEN
3. Verify your internet connection is stable
  
- `/check <cards>` - Check cards (format: card|mm|yyyy|cvv)
- `/stop` - Stop current checking process
- `/help` - Show help message

## Usage Example

1. Start bot: `/start`
2. Select a gateway from the menu
3. Send cards in format:
```
/check 4107486757451294|06|2026|237
5358251949963942|08|2025|636
```

## Card Format

```
cardnumber|month|year|cvv
```

Example:
```
4107486757451294|06|2026|237
```

## Notes

- This is a simulation bot for demonstration purposes
- Real gateway integration requires proper API keys and compliance
- Keep your bot token secure
- Don't share sensitive information

## Troubleshooting

**Bot not responding:**
- Check if bot token is correct
- Ensure bot is running
- Check internet connection

**Termux issues:**
- Use F-Droid version, not Play Store
- Grant storage permissions: `termux-setup-storage`
- Keep app open or use background running

**Dependencies issues:**
```bash
rm -rf node_modules package-lock.json
npm install
```