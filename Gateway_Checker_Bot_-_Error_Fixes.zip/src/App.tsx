import React, { useState } from 'react';
import Header from './components/Header';
import CheckingCard from './components/CheckingCard';
import ControlPanel from './components/ControlPanel';
import { CheckResult } from './types';
import { checkCard } from './utils/checker';
import './App.css';

function App() {
  const [cards, setCards] = useState<string[]>([]);
  const [gateway, setGateway] = useState('PayPal_Custom_Cvv_Refund');
  const [amount, setAmount] = useState('1');
  const [results, setResults] = useState<CheckResult[]>([]);
  const [isChecking, setIsChecking] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [stats, setStats] = useState({
    charged: 0,
    approved: 0,
    declined: 0,
    total: 0
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        const cardList = text.split('\n').filter(line => line.trim());
        setCards(cardList);
        setResults([]);
        setStats({ charged: 0, approved: 0, declined: 0, total: cardList.length });
      };
      reader.readAsText(file);
    }
  };

  const startChecking = async () => {
    if (cards.length === 0) return;
    
    setIsChecking(true);
    setResults([]);
    setCurrentIndex(0);
    
    let charged = 0;
    let approved = 0;
    let declined = 0;

    for (let i = 0; i < cards.length; i++) {
      if (!isChecking) break;
      
      setCurrentIndex(i + 1);
      const result = await checkCard(cards[i], gateway, amount);
      
      if (result.status === 'charged') charged++;
      else if (result.status === 'approved') approved++;
      else declined++;
      
      setStats({
        charged,
        approved,
        declined,
        total: cards.length
      });
      
      setResults(prev => [...prev, result]);
      
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
    
    setIsChecking(false);
  };

  const stopChecking = () => {
    setIsChecking(false);
  };

  return (
    <div className="app">
      <Header />
      
      <div className="container">
        <ControlPanel
          gateway={gateway}
          amount={amount}
          onGatewayChange={setGateway}
          onAmountChange={setAmount}
          onFileUpload={handleFileUpload}
          onStart={startChecking}
          onStop={stopChecking}
          isChecking={isChecking}
          stats={stats}
          currentIndex={currentIndex}
          totalCards={cards.length}
        />

        <div className="results-container">
          {results.map((result, index) => (
            <CheckingCard
              key={index}
              result={result}
              index={index + 1}
              totalChecks={cards.length}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;