import React from 'react';
import { Shield } from 'lucide-react';
import './Header.css';

function Header() {
  return (
    <header className="header">
      <div className="header-content">
        <div className="logo">
          <Shield size={32} />
        </div>
        <div className="header-text">
          <h1>Gateway Checker</h1>
          <p>Company Payment Gateway Validator</p>
        </div>
      </div>
    </header>
  );
}

export default Header;