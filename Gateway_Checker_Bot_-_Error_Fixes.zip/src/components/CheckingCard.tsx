import React from 'react';
import { CreditCard, CheckCircle, XCircle, Flame } from 'lucide-react';
import { CheckResult } from '../types';
import { formatCardNumber } from '../utils/checker';
import './CheckingCard.css';

interface CheckingCardProps {
  result: CheckResult;
  index: number;
  totalChecks: number;
}

function CheckingCard({ result, index, totalChecks }: CheckingCardProps) {
  const getStatusIcon = () => {
    switch (result.status) {
      case 'charged':
        return <Flame className="status-icon charged" />;
      case 'approved':
        return <CheckCircle className="status-icon approved" />;
      case 'declined':
        return <XCircle className="status-icon declined" />;
    }
  };

  const getStatusText = () => {
    switch (result.status) {
      case 'charged':
        return 'Order Was Charged';
      case 'approved':
        return 'Order Was Approved';
      case 'declined':
        return 'Order Was Declined';
    }
  };

  return (
    <div className={`checking-card ${result.status}`}>
      <div className="card-header">
        <CreditCard size={20} />
        <span>Checking {index}/{totalChecks}...</span>
      </div>
      
      <div className="card-info">
        <div className="gateway-info">
          Gateway: <span className="highlight">#{result.gateway}</span> (${result.amount})
        </div>
        <div className="remaining">
          Remaining checks: {totalChecks - index}.0
        </div>
      </div>

      <div className="card-number">
        Card: {formatCardNumber(result.cardNumber)}
      </div>

      <div className="status-badge">
        Status: {getStatusText()}
      </div>

      <div className="stats-row">
        <div className="stat-item charged">
          {getStatusIcon()}
          Charged: {result.status === 'charged' ? 1 : 0}
        </div>
        <div className="stat-item approved">
          <CheckCircle size={16} />
          Approved: {result.status === 'approved' ? 1 : 0}
        </div>
      </div>

      <div className="declined-stat">
        <XCircle size={16} />
        Declined: {result.status === 'declined' ? 1 : 0}
      </div>
    </div>
  );
}

export default CheckingCard;