import React from 'react';
import { Play, Square, Upload, Activity } from 'lucide-react';
import { Stats } from '../types';
import './ControlPanel.css';

interface ControlPanelProps {
  gateway: string;
  amount: string;
  onGatewayChange: (value: string) => void;
  onAmountChange: (value: string) => void;
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onStart: () => void;
  onStop: () => void;
  isChecking: boolean;
  stats: Stats;
  currentIndex: number;
  totalCards: number;
}

function ControlPanel({
  gateway,
  amount,
  onGatewayChange,
  onAmountChange,
  onFileUpload,
  onStart,
  onStop,
  isChecking,
  stats,
  currentIndex,
  totalCards
}: ControlPanelProps) {
  return (
    <div className="control-panel">
      <div className="input-group">
        <label>Gateway</label>
        <select value={gateway} onChange={(e) => onGatewayChange(e.target.value)}>
          <option value="PayPal_Custom_Cvv_Refund">PayPal Custom CVV Refund</option>
          <option value="Stripe_Standard">Stripe Standard</option>
          <option value="Authorize_Net">Authorize.Net</option>
          <option value="Braintree_Gateway">Braintree Gateway</option>
        </select>
      </div>

      <div className="input-group">
        <label>Amount ($)</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => onAmountChange(e.target.value)}
          min="0.01"
          step="0.01"
        />
      </div>

      <div className="file-upload">
        <label htmlFor="file-input" className="file-label">
          <Upload size={18} />
          <span>Upload Cards File</span>
        </label>
        <input
          id="file-input"
          type="file"
          accept=".txt"
          onChange={onFileUpload}
          style={{ display: 'none' }}
        />
        {totalCards > 0 && (
          <span className="file-info">{totalCards} cards loaded</span>
        )}
      </div>

      <div className="stats-panel">
        <div className="stat">
          <Activity size={16} />
          <span>Progress: {currentIndex}/{totalCards}</span>
        </div>
        <div className="stat-grid">
          <div className="stat-box charged">
            <span className="stat-value">{stats.charged}</span>
            <span className="stat-label">Charged</span>
          </div>
          <div className="stat-box approved">
            <span className="stat-value">{stats.approved}</span>
            <span className="stat-label">Approved</span>
          </div>
          <div className="stat-box declined">
            <span className="stat-value">{stats.declined}</span>
            <span className="stat-label">Declined</span>
          </div>
        </div>
      </div>

      <div className="button-group">
        {!isChecking ? (
          <button
            className="btn btn-start"
            onClick={onStart}
            disabled={totalCards === 0}
          >
            <Play size={18} />
            Start Checking
          </button>
        ) : (
          <button className="btn btn-stop" onClick={onStop}>
            <Square size={18} />
            Stop Checking
          </button>
        )}
      </div>
    </div>
  );
}

export default ControlPanel;