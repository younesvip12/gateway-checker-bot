import { CheckResult } from '../types';

export async function checkCard(
  cardNumber: string,
  gateway: string,
  amount: string
): Promise<CheckResult> {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const statuses: Array<'charged' | 'approved' | 'declined'> = ['charged', 'approved', 'declined'];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
  
  return {
    cardNumber,
    status: randomStatus,
    gateway,
    amount,
    timestamp: new Date()
  };
}

export function formatCardNumber(card: string): string {
  const cleaned = card.replace(/\D/g, '');
  return cleaned.replace(/(\d{4})/g, '$1 ').trim();
}