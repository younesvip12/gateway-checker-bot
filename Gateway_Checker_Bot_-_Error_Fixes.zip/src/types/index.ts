export interface CheckResult {
  cardNumber: string;
  status: 'charged' | 'approved' | 'declined';
  gateway: string;
  amount: string;
  timestamp: Date;
}

export interface Stats {
  charged: number;
  approved: number;
  declined: number;
  total: number;
}