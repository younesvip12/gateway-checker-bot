# 📱 Complete Setup Guide - Step by Step

## Part 1: Create Your Telegram Bot (5 minutes)

### Step 1: Open Telegram on Your Phone
1. Open Telegram app
2. In the search bar, type: `@BotFather`
3. Click on the official BotFather (has a blue checkmark)

### Step 2: Create New Bot
1. Click **START** button
2. Type: `/newbot` and send
3. BotFather will ask for a name - Type any name like: `My Gateway Checker`
4. BotFather will ask for a username - Type something like: `mygateway_checker_bot` (must end with _bot)
5. **IMPORTANT**: Copy the token that looks like this:
   ```
   123456789:ABCdefGHIjklMNOpqrsTUVwxyz
   ```
   Save this token somewhere safe!

---

## Part 2: Choose Your Method

### 🌟 EASIEST METHOD - Use Railway (Recommended for Beginners)

**What you need:**
- Email address
- GitHub account (free)
- The bot token from Part 1

**Steps:**

#### 1. Create GitHub Account (if you don't have one)
- Go to github.com on your phone browser
- Click "Sign up"
- Follow the steps

#### 2. Upload Code to GitHub
- Go to github.com/new
- Name your repository: `gateway-bot`
- Click "Create repository"
- Click "uploading an existing file"
- Upload all the bot files from this project
- Click "Commit changes"

#### 3. Deploy on Railway
- Go to railway.app on your phone browser
- Click "Start a New Project"
- Click "Deploy from GitHub repo"
- Select your `gateway-bot` repository
- Click "Add variables"
- Add this variable:
  - Name: `BOT_TOKEN`
  - Value: paste your bot token from Part 1
- Click "Deploy"
- Wait 2-3 minutes

✅ **Done!** Your bot is now running 24/7!

---

### 📱 METHOD 2 - Run on Android Phone (Termux)

**What you need:**
- Android phone
- Internet connection
- 30 minutes

**Steps:**

#### Step 1: Install Termux
1. Open your phone's browser
2. Go to: `f-droid.org`
3. Download F-Droid app
4. Install F-Droid
5. Open F-Droid
6. Search for "Termux"
7. Install Termux

#### Step 2: Setup Termux
Open Termux and type these commands **one by one**:

```bash
# Press Enter after each line

pkg update

pkg upgrade

pkg install nodejs-lts

pkg install git

cd ~

mkdir gateway-bot

cd gateway-bot
```

#### Step 3: Add Your Files
Now you need to add the bot files to your phone:

**Option A - Easy Way:**
1. Download all bot files to your phone
2. Move them to: `/storage/emulated/0/gateway-bot/`
3. In Termux type:
```bash
cp /storage/emulated/0/gateway-bot/* ~/gateway-bot/
```

**Option B - If you have GitHub:**
```bash
git clone YOUR_GITHUB_REPO_URL
cd gateway-bot
```

#### Step 4: Create .env File
```bash
# Type this command:
nano .env
```

Now type this (replace with your actual token):
```
BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
ADMIN_IDS=your_telegram_user_id
```

Press: `Ctrl + X`, then `Y`, then `Enter`

#### Step 5: Install and Run
```bash
npm install

npm start
```

✅ **Your bot is now running!**

**Important Notes:**
- Keep Termux app open
- Don't close it or bot will stop
- To stop bot: Press `Ctrl + C`
- To run again: Type `npm start`

---

## Part 3: Test Your Bot

1. Open Telegram
2. Search for your bot username (the one you created in Part 1)
3. Click **START**
4. You should see a welcome message!

### How to Use the Bot:

1. Click a gateway button (like PayPal)
2. Create a text file with cards in this format:
   ```
   4107486757451294|06|2026|237
   5358251949963942|08|2025|636
   ```
3. Send the file to the bot
4. Wait for results!

---

## 📊 Quick Reference

### Bot Commands:
- `/start` - Start the bot
- `/help` - Show help
- `/stop` - Stop checking

### File Format for Cards:
```
cardnumber|month|year|cvv
4107486757451294|06|2026|237
```

### If Bot Not Working:
1. Check bot token is correct
2. Make sure Termux is open (if using Method 2)
3. Check internet connection
4. Restart bot: Press `Ctrl+C` then type `npm start`

---

## 🆘 Common Problems & Solutions

**Problem: Bot doesn't respond**
- Solution: Make sure bot is running (check Railway dashboard or Termux)

**Problem: "Cannot find module" error**
- Solution: Run `npm install` again

**Problem: Bot stops when I close Termux**
- Solution: Use Railway instead for 24/7 running

**Problem: "Unauthorized" error**
- Solution: Check your BOT_TOKEN in .env file

---

## 💡 Tips

- **For Railway**: Free plan gives you 500 hours/month (about 20 days)
- **For Termux**: Bot only runs when app is open
- **Keep your bot token SECRET** - don't share it!
- You can check bot status by sending `/start` command

---

## Need More Help?

If you're stuck on any step, tell me which step number you're on and what error you see!