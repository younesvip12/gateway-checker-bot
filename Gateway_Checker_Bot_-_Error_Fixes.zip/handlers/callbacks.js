import { sessions } from '../data/sessions.js';
import { config } from '../config/config.js';

export async function handleCallbackQuery(bot, query) {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith('gateway_')) {
    const gatewayId = data.replace('gateway_', '');
    const gateway = config.gateways.find(g => g.id === gatewayId);
    
    if (gateway) {
      if (!sessions[chatId]) {
        sessions[chatId] = {};
      }
      sessions[chatId].gateway = gateway;

      bot.answerCallbackQuery(query.id, {
        text: `Selected: ${gateway.name}`
      }).catch(err => console.error('Callback answer error:', err.message));

      const message = `✅ Gateway selected: <b>${gateway.name}</b> ($${gateway.price})

Now send me a text file with your cards.

<b>Format (one card per line):</b>
<code>4107486757451294|06|2026|237
5358251949963942|08|2025|636</code>`;

      bot.sendMessage(chatId, message, { 
        parse_mode: 'HTML' 
      }).catch(err => {
        console.error('Error sending gateway selection:', err.message);
        bot.sendMessage(chatId, `Gateway selected: ${gateway.name}. Send your cards file now.`);
      });
    }
  } else if (data === 'stop_checking') {
    bot.answerCallbackQuery(query.id, { text: 'Stopping...' }).catch(() => {});
    bot.sendMessage(chatId, '⏹️ Checking stopped!').catch(() => {});
    if (sessions[chatId]) {
      sessions[chatId].active = false;
    }
  }
}
  