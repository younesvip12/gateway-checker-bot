import { getMainKeyboard } from '../utils/keyboard.js';
import { startChecking, stopChecking } from '../services/checker.js';
import { sessions } from '../data/sessions.js';

export function handleStart(bot, msg) {
  const chatId = msg.chat.id;
  const welcomeMessage = `🤖 <b>Welcome to Gateway Checker Bot!</b>

This bot helps you check payment card validity across multiple gateways.

<b>Commands:</b>
/start - Show gateway options
/stop - Stop current checking process
/help - Show this help message

<b>How to use:</b>
1. Select a gateway from the buttons below
2. Send a text file with card details (one per line)
3. Format: cardnumber|month|year|cvv
4. Example: 4107486757451294|06|2026|237

Choose a gateway to begin:`;

  bot.sendMessage(chatId, welcomeMessage, {
    parse_mode: 'HTML',
    reply_markup: getMainKeyboard()
  }).catch(err => {
    console.error('Error in handleStart:', err.message);
    bot.sendMessage(chatId, 'Welcome! Use the buttons below to select a gateway.', {
      reply_markup: getMainKeyboard()
    });
  });
}

export function handleHelp(bot, msg) {
  const chatId = msg.chat.id;
  handleStart(bot, msg);
}

export function handleStop(bot, msg) {
  const chatId = msg.chat.id;
  stopChecking(bot, msg);
}
  
  }

  await startChecking(bot, chatId, cards, sessions[chatId].gateway);
}

export function handleStop(bot, msg) {
  const chatId = msg.chat.id;
  stopChecking(chatId);
  bot.sendMessage(chatId, '🛑 Checking process stopped!');
}