import { sessions } from '../data/sessions.js';
import { startChecking } from '../services/checker.js';

export async function handleDocument(bot, msg) {
  const chatId = msg.chat.id;
  const document = msg.document;

  if (!sessions[chatId] || !sessions[chatId].gateway) {
    bot.sendMessage(chatId, '⚠️ Please select a gateway first using /start');
    return;
  }

  if (document.mime_type !== 'text/plain') {
    bot.sendMessage(chatId, '❌ Please send a text file (.txt)');
    return;
  }

  try {
    const fileLink = await bot.getFileLink(document.file_id);
    const response = await fetch(fileLink);
    const text = await response.text();
    
    const cards = text.split('\n')
      .map(line => line.trim())
      .filter(line => line && line.includes('|'));

    if (cards.length === 0) {
      bot.sendMessage(chatId, '❌ No valid cards found. Format: cardnumber|month|year|cvv');
      return;
    }

    bot.sendMessage(chatId, `✅ Loaded ${cards.length} cards. Starting check...`);
    startChecking(bot, chatId, cards, sessions[chatId].gateway);

  } catch (error) {
    console.error('Error processing file:', error);
    bot.sendMessage(chatId, '❌ Error processing file. Please try again.');
  }
}