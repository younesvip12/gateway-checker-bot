export async function checkGateway(card, gateway) {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const [cardNumber, month, year, cvv] = card.split('|');
  
  if (!cardNumber || !month || !year || !cvv) {
    return {
      status: 'error',
      message: 'Invalid card format'
    };
  }

  const random = Math.random();
  
  if (random < 0.3) {
    return {
      status: 'approved',
      message: 'Transaction approved',
      charged: gateway.price
    };
  } else if (random < 0.7) {
    return {
      status: 'declined',
      message: 'Insufficient funds'
    };
  } else {
    return {
      status: 'declined',
      message: 'Card declined'
    };
  }
}
  