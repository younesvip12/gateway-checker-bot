import { formatCardInfo, formatStatusMessage } from '../utils/formatter.js';
import { checkGateway } from './gateway.js';

const activeChecks = {};

export async function startChecking(bot, chatId, cards, gateway) {
  if (activeChecks[chatId]) {
    bot.sendMessage(chatId, '⚠️ A checking process is already running!').catch(() => {});
    return;
  }

  activeChecks[chatId] = { active: true, checked: 0, total: cards.length };

  const stats = {
    total: cards.length,
    checked: 0,
    approved: 0,
    declined: 0,
    charged: 0
  };

  let statusMsg;
  try {
    statusMsg = await bot.sendMessage(
      chatId,
      formatStatusMessage(0, cards.length, gateway, stats),
      { parse_mode: 'HTML' }
    );
  } catch (err) {
    console.error('Error sending status:', err.message);
    statusMsg = await bot.sendMessage(chatId, 'Starting check...');
  }

  for (let i = 0; i < cards.length; i++) {
    if (!activeChecks[chatId]?.active) {
      break;
    }

    const card = cards[i].trim();
    if (!card) continue;

    try {
      const result = await checkGateway(card, gateway);
      stats.checked++;
      
      if (result.status === 'approved') stats.approved++;
      else if (result.status === 'declined') stats.declined++;
      if (result.charged) stats.charged++;

      const resultMessage = formatCardInfo(i + 1, cards.length, card, result, gateway);
      
      bot.sendMessage(chatId, resultMessage, { parse_mode: 'HTML' }).catch(err => {
        console.error('Error sending result:', err.message);
      });

      if ((i + 1) % 5 === 0 || i === cards.length - 1) {
        try {
          await bot.editMessageText(
            formatStatusMessage(stats.checked, cards.length, gateway, stats),
            {
              chat_id: chatId,
              message_id: statusMsg.message_id,
              parse_mode: 'HTML'
            }
          );
        } catch (err) {
          console.error('Error updating status:', err.message);
        }
      }

      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (err) {
      console.error('Error checking card:', err.message);
    }
  }

  delete activeChecks[chatId];
  
  bot.sendMessage(chatId, `✅ <b>Checking Complete!</b>

📊 Final Results:
Total: ${stats.total}
✅ Approved: ${stats.approved}
❌ Declined: ${stats.declined}
💰 Charged: ${stats.charged}`, { parse_mode: 'HTML' }).catch(() => {});
}

export function stopChecking(bot, msg) {
  const chatId = msg.chat.id;
  
  if (activeChecks[chatId]) {
    activeChecks[chatId].active = false;
    delete activeChecks[chatId];
    bot.sendMessage(chatId, '⏹️ Checking stopped!').catch(() => {});
  } else {
    bot.sendMessage(chatId, '⚠️ No active checking process.').catch(() => {});
  }
}
  