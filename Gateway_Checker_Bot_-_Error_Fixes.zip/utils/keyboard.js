import { config } from '../config/config.js';

export function getMainKeyboard() {
  const buttons = config.gateways.map(gateway => [{
    text: `${gateway.name} ($${gateway.price})`,
    callback_data: `gateway_${gateway.id}`
  }]);

  return {
    inline_keyboard: buttons
  };
}

export function getStopButton() {
  return {
    inline_keyboard: [[
      { text: '🛑 Stop Check', callback_data: 'stop_checking' }
    ]]
  };
}