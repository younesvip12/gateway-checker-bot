export function formatCardInfo(index, total, card, result, gateway) {
  const [cardNumber, month, year, cvv] = card.split('|');
  const masked = cardNumber.substring(0, 6) + 'xx' + cardNumber.substring(cardNumber.length - 4);
  
  const statusEmoji = result.status === 'approved' ? '✅' : 
                      result.status === 'declined' ? '❌' : '⚠️';
  
  return `<b>Card ${index}/${total}</b>
${statusEmoji} Status: ${result.status.toUpperCase()}
💳 Card: <code>${masked}|${month}|${year}|xxx</code>
🏦 Gateway: ${gateway.name}
📝 Response: ${result.message || 'No message'}
${result.charged ? '💰 Charged: $' + result.charged : ''}

━━━━━━━━━━━━━━━━`;
}

export function formatStatusMessage(checked, total, gateway, stats) {
  const progress = Math.round((checked / total) * 100);
  const progressBar = '▓'.repeat(Math.floor(progress / 5)) + '░'.repeat(20 - Math.floor(progress / 5));
  
  return `<b>🔄 Checking Progress</b>

${progressBar} ${progress}%

📊 <b>Statistics:</b>
Total: ${stats.total}
Checked: ${stats.checked}
✅ Approved: ${stats.approved}
❌ Declined: ${stats.declined}
💰 Charged: ${stats.charged}

🏦 Gateway: ${gateway.name}`;
}
  